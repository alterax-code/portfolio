# 🚀 Portfolio Lucas Jacob - Next.js

Portfolio professionnel de développeur web full-stack, migré vers **Next.js 14** avec API Routes et TypeScript.

![Next.js](https://img.shields.io/badge/Next.js-14-black)
![React](https://img.shields.io/badge/React-18-blue)
![TypeScript](https://img.shields.io/badge/TypeScript-5-blue)

## 🌐 Voir en ligne

**Production:** À venir sur Vercel  
**GitHub:** [https://github.com/alterax-code/portfolio](https://github.com/alterax-code/portfolio)

## ✨ Fonctionnalités

- ✅ Design dark/rouge moderne et responsive
- ✅ Système de likes avec API Next.js (protection anti-spam par cookies)
- ✅ Animations fluides (typing effect, scroll, fade-in)
- ✅ Modale CV interactive
- ✅ Navigation smooth
- ✅ SEO optimisé avec métadonnées Next.js
- ✅ Performance optimale avec Next.js 14
- ⏳ Webhooks GitHub (à venir)

## 🛠️ Technologies utilisées

### Frontend
- **Next.js 14** - Framework React avec App Router
- **React 18** - Library UI
- **TypeScript** - Typage statique
- **CSS3** - Styles personnalisés (thème dark/rouge)

### Backend
- **Next.js API Routes** - API RESTful intégrée
- **Node.js** - Runtime JavaScript
- **File System** - Stockage JSON pour les likes

## 📁 Structure du projet

```
portfolio/
├── app/
│   ├── api/
│   │   └── likes/
│   │       └── route.ts          # API des likes (remplace likes.php)
│   ├── globals.css               # Styles (thème dark/rouge)
│   ├── layout.tsx                # Layout principal + métadonnées
│   └── page.tsx                  # Page d'accueil (portfolio complet)
├── components/
│   ├── ClientScripts.tsx         # Effets JavaScript (typing, scroll)
│   ├── CVModal.tsx               # Modale pour afficher le CV
│   └── LikeButton.tsx            # Bouton like interactif
├── data/
│   └── likes.json                # Stockage des likes
├── public/
│   └── assets/
│       ├── images/               # Images du portfolio
│       └── documents/            # CV PDF
├── next.config.js
├── package.json
└── tsconfig.json
```

## 🚀 Installation

### Prérequis
- Node.js 18+ 
- npm ou yarn

### Étapes

1. **Cloner le repo**
```bash
git clone https://github.com/alterax-code/portfolio.git
cd portfolio
```

2. **Installer les dépendances**
```bash
npm install
```

3. **Placer vos assets**
```bash
# Assurez-vous que vos images sont dans public/assets/images/
# Et vos documents (CV) dans public/assets/documents/
```

4. **Lancer le serveur de développement**
```bash
npm run dev
```

Ouvrez [http://localhost:3000](http://localhost:3000) dans votre navigateur.

## 📜 Scripts disponibles

```bash
npm run dev      # Développement (localhost:3000)
npm run build    # Build de production
npm start        # Démarrer en production
npm run lint     # Linter TypeScript/ESLint
```

## 🔧 Configuration

### Modifier les projets affichés

Éditez `app/page.tsx` et modifiez la section `#last-projects`.

### Modifier les likes initiaux

Éditez `data/likes.json` :
```json
{
  "site-recettes": 0,
  "jeu-pygame": 0,
  "jeu-unreal": 0
}
```

## 🌐 Déploiement

### Vercel (Recommandé - GRATUIT)

1. Push votre code sur GitHub
2. Allez sur [vercel.com](https://vercel.com)
3. Importez votre repo
4. Vercel détecte automatiquement Next.js
5. Déployez !

### Autres options
- **Netlify** : Compatible Next.js
- **AWS Amplify** : Déploiement automatique
- **VPS** : Build avec `npm run build` + serveur Node.js

## 📊 Performance

- ⚡ Score Lighthouse : 95+
- 🚀 First Contentful Paint : < 1.5s
- 🎨 Design responsive (mobile/tablette/desktop)
- ♿ Accessibilité : Navigation clavier + ARIA

## 🔐 API Routes

### GET /api/likes?action=get
Récupère tous les likes
```json
{
  "success": true,
  "likes": {
    "site-recettes": 5,
    "jeu-pygame": 3,
    "jeu-unreal": 2
  }
}
```

### POST /api/likes
Ajoute un like (protection par cookie)
```json
{
  "project": "site-recettes"
}
```

## 🎯 Roadmap

- [x] Migration vers Next.js
- [x] API Routes pour les likes
- [x] Design dark/rouge préservé
- [ ] Webhooks GitHub pour projets dynamiques
- [ ] Formulaire de contact fonctionnel
- [ ] Blog intégré
- [ ] Mode clair/sombre
- [ ] Internationalisation (FR/EN)

## 🤝 Contact

- **GitHub** : [@alterax-code](https://github.com/alterax-code)
- **LinkedIn** : [Lucas Jacob](https://www.linkedin.com/in/jcb-dev/)
- **Email** : contact@lucasjacob.dev

## 📝 Licence

Ce projet est réalisé dans un cadre éducatif - EPITECH 2024-2025

---

Réalisé avec passion et migré vers Next.js par Lucas Jacob 🚀
